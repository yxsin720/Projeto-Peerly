package com.peerly.peerly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeerlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
