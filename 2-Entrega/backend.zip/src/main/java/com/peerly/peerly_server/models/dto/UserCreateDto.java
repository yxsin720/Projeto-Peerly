package com.peerly.peerly_server.models.dto;

public class UserCreateDto {
    public String fullName;
    public String email;
    public String password;
    public String avatarUrl;
}
