package com.peerly.peerly_server.models.dto;

public class UserUpdateDto {
    public String fullName;
    public String avatarUrl;
}
