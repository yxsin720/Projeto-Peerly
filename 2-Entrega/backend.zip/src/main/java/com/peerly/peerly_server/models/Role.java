package com.peerly.peerly_server.models;
public enum Role { student, tutor, both, admin }
